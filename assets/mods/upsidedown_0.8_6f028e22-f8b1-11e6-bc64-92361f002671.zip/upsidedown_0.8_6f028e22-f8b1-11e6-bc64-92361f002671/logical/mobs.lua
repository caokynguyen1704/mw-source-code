
function wildman_Interact(mob, player)
	local id =	ModMgr:getMonsterIdByName("wildman_tamed");
	return TameAnimal_Interact(mob, player, 11204, id, 5);
end

function wildman_tamed_Interact(mob, player)
	local itemid = player:getCurToolID()
	if mob:getTamed() then
		if  mob:getTamedOwnerID() == player:getUin() and (0 == mob:isBreedItem(itemid))  then
			mob:setAISitting(not mob:getSitting())
			return true
		end
	end
end	


function wildmanhunter_Interact(mob, player)
	local id =	ModMgr:getMonsterIdByName("wildmanhunter_tamed");
	return TameAnimal_Interact(mob, player, 11204, id, 5);
end

function wildmanhunter_tamed_Interact(mob, player)
	local itemid = player:getCurToolID()
	if mob:getTamed() then
		if  mob:getTamedOwnerID() == player:getUin() and (0 == mob:isBreedItem(itemid))  then
			mob:setAISitting(not mob:getSitting())
			return true
		end
	end
end	

function littlewildman_Interact(mob, player)
	local id =	ModMgr:getMonsterIdByName("littlewildman_tamed");
	return TameAnimal_Interact(mob, player, 11204, id, 5);
end

function littlewildman_tamed_Interact(mob, player)
	local itemid = player:getCurToolID()
	if mob:getTamed() then
		if  mob:getTamedOwnerID() == player:getUin() and (0 == mob:isBreedItem(itemid))  then
			mob:setAISitting(not mob:getSitting())
			return true
		end
	end
end	