function human_win()
	ClientCurGame:sendChat(GetS(8023),  1);
	ClientCurGame:setTeamScore(2, 1);  --人类为队伍2（蓝队）
	ClientCurGame:setTeamScore(1, 0);  --野人为队伍1（红队）
	ClientCurGame:setTeamResults(1, 2);
	ClientCurGame:setTeamResults(2, 1);
	ClientCurGame:setPlayersResults(1, 2);
	ClientCurGame:setPlayersResults(2, 1);
end
function zombie_win()
	ClientCurGame:sendChat(GetS(8024), 1);
	ClientCurGame:setTeamScore(2, 0);
	ClientCurGame:setTeamScore(1, 1);
	ClientCurGame:setTeamResults(1, 1);
	ClientCurGame:setTeamResults(2, 2);
	ClientCurGame:setPlayersResults(1, 1);
	ClientCurGame:setPlayersResults(2, 2);
end
wes_gamestart = function()
	local team2 = ClientCurGame:getNumPlayers(2);
	if team2 <=1 then return 0 end --单人模式不计胜负
	if team2 >0 then ClientCurGame:setTeamScore(2, team2) end
	local player = ClientCurGame:getRandomPlayer(2) --取随机玩家
	if player == nil then return 0 end
	player:kill();
	local info = player:getNickname()..GetS(8025);
	ClientCurGame:sendChat(info, 1);
	return 1;
end
wes_player_die = function(player, killedby) --死亡换队伍
	--player:setTeam(1)
	ClientCurGame:changePlayerTeam(player:getUin(), 1)
	if player:getUin() == AccountManager:getUin() then	
		OnChangeTeam();
	end
	
	local info2 = player:getNickname()..GetS(8026);
	ClientCurGame:sendChat(info2, 1);
	return 1;
end
wes_player_revive = function(player) --复活加BUFF
	player:getLivingAttrib():addBuff(1002, 1);
	player:getLivingAttrib():addBuff(1010, 1);
	return 1;
end

wes_gamerun = function()
	local team1 = ClientCurGame:getNumPlayers(1, 1);
	local team2 = ClientCurGame:getNumPlayers(2, 1);
	if team1 >0 then ClientCurGame:setTeamScore(1, team1) end --存活人数=分数
	if team2 >0 then ClientCurGame:setTeamScore(2, team2) end --存活人数=分数
	
	if ClientCurGame:getNumPlayers(1) + ClientCurGame:getNumPlayers(2) <= 1 then return 0 end
	if team2 == 0 then
		zombie_win();
		return 1;
	end
	if team1 + ClientCurGame:getNumPlayers(1, 0) == 0 then
		human_win();
		return 1;
	end
	
	return 0
end
wes_game_timeover = function()
	local sur = ClientCurGame:getNumPlayers(2, 1) --（2,1）为存活的蓝队队员
	if sur > 0 then
		human_win();
	else
		zombie_win();
	end
end
wes_enter_teamid = function(player)
	return 2
end
