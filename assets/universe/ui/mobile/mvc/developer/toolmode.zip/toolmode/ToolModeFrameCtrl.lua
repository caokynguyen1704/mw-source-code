--声明
local ToolModeFrameCtrl = Class("ToolModeFrameCtrl",ClassList["UIBaseCtrl"])

--创建
function ToolModeFrameCtrl:Create(param)
	print("ToolModeFrameCtrl:Create:");
	return ClassList["ToolModeFrameCtrl"].new(param)
end

--初始化
function ToolModeFrameCtrl:Init(param)
	print("ToolModeFrameCtrl:Init:");
	--界面常量定义
	self.curToolMode = 0;

	self.update = {};
	self.update.oldToolMode = 0;
	self.update.oldState = 0;
	self.update.shortcutShown = false;
	self.update.backpackShown = false;

	--注册事件
	getglobal("ToolModeFrame"):RegisterEvent("GE_TOOLMODE_AREA_REEVIEWPOS");
	getglobal("ToolModeFrame"):RegisterEvent("GE_TOOLMODE_COMMON");
	getglobal("ToolModeFrame"):RegisterEvent("GIE_ENTER_WORLD");
	getglobal("ToolModeFrame"):setUpdateTime(0.5);
end

--事件处理
function ToolModeFrameCtrl:OnEvent()
	-- print("ToolModeFrameCtrl:OnEvent:");
	local ge = GameEventQue:getCurEvent();

	if ge and arg1 == "GE_TOOLMODE_AREA_REEVIEWPOS" then
		local ToolType = ge.body.toolmodePreviewPosInfo.nToolType;
		local state = ge.body.toolmodePreviewPosInfo.state;
        local x = ge.body.toolmodePreviewPosInfo.x;
        local y = ge.body.toolmodePreviewPosInfo.y;
		local z = ge.body.toolmodePreviewPosInfo.z;
		
		-- print("ToolType = ", ToolType, ", state = ", state, ", x = ", x, ", y = ", y, ", z = ", z);
		if ToolType == TOOL_MODE_DISPLAYBOARD then
			ToolType = 4;
		end
		self.view:UpdatePreviewFrame(ToolType, x, y, z);
	elseif ge and arg1 == "GE_TOOLMODE_COMMON" then
		local ToolType = ge.body.toolmodeCommonInfo.nToolType;
		local nHandleType = ge.body.toolmodeCommonInfo.nHandleType;
		local nRet = ge.body.toolmodeCommonInfo.nRet;
		local nameIndex = ge.body.toolmodeCommonInfo.nameIndex;
		local nState = ge.body.toolmodeCommonInfo.nState;
		local name = ge.body.toolmodeCommonInfo.name;

		print("ToolModeFrameCtrl:OnEvent ToolType = ", ToolType, ", nHandleType = ", nHandleType);
		if nRet == 1 and nHandleType == 1 then
			--nHandleType==1:创建
			--创建成功飘字提示
			local bCreate = false;
			if ToolType == 1 and nState == 0 then
				ShowGameTips(GetS(14519, nameIndex), 3);
				bCreate = true;
				standReportEvent("2001", "MINI_MINEMAP_GAME_1", "", "develop_regiontool")
			elseif ToolType == 2 then
				ShowGameTips(GetS(14520, nameIndex), 3);
				bCreate = true;
				standReportEvent("2001", "MINI_MINEMAP_GAME_1", "", "develop_locationtool")
			elseif ToolType == 3 and nState > 0 then
				ShowGameTips(GetS(14521, name), 3);
				bCreate = true;
				standReportEvent("2001", "MINI_MINEMAP_GAME_1", "", "develop_biologytool")
			elseif ToolType == 5 then
				if nState == 0 then
					ShowGameTips(GetS(14541, nameIndex), 3);
					bCreate = true;
				end
			end

			--刷新界面
			local state = self:GetCurToolState();
			self.view:Refresh(self.curToolMode, state, LivingToolMgr:getSelectType());

			--如果打开流程是: 触发器-对象库-工具模式, 那么创建成功后弹出对象库, 以供选择
			if bCreate then
				print("is create:")
				
				if self:IsUseMode() then
					print("111:");
					local param = self.model:GetIncomingParam();
					print(param);

					local objLibParam = param.objLibParam;
					if objLibParam then
						print("222");
						if self.curToolMode == TOOL_MODE_ACTOR then
							LivingToolMgr:cancelSelect()
						end
						GetInst("UIManager"):Open("ToolObjLib", objLibParam);
						--这里变成鼠标模式
						if CurMainPlayer and CurMainPlayer:isSightMode() then
							CurMainPlayer:setSightMode(false);
						end
					end
				end
			end
		elseif nRet == 1 and nHandleType == 2 then
			--nHandleType == 2:重摆
			if ToolType == 1 and nState == 2 then
				--区域重摆成功
				local tips = GetS(14531, name);
				ShowGameTips(tips, 3);
			end

			--刷新界面
			local state = self:GetCurToolState();
			self.view:Refresh(self.curToolMode, state, LivingToolMgr:getSelectType());
		elseif nHandleType == 3 then
			--进入/退出工具模式
			--刷新工具模式UI
			if IsUIFrameShown(self.define.uiName) then
				self:Refresh();
			end
		end
	elseif ge and arg1 == "GIE_ENTER_WORLD" then
		--进入世界的时候触发: 1. 进入存档 2.从地表进入地底世界等...

		--关闭对象库
		if IsUIFrameShown("ToolObjLib") then
			GetInst("UIManager"):Close("ToolObjLib");
		end

		--刷新工具模式UI
		-- if getglobal(self.define.uiName):IsShown() then
		-- 	self:Refresh();
		-- end
	end
end

function ToolModeFrameCtrl:CloseBtnClicked()
	GetInst("UIManager"):Close(self.define.uiName);
end

--update
function ToolModeFrameCtrl:OnUpdate()
	local curToolMode = self.curToolMode;
	local state = 0;

	----
	-- local needUpdate = false;
	-- if getglobal("PlayShortcut"):IsShown() then
	-- 	if self.update.shortcutShown == false then
	-- 		needUpdate = true;
	-- 	end
	-- else
	-- 	if self.update.shortcutShown == true then
	-- 		needUpdate = true;
	-- 	end
	-- end

	-- if getglobal("PlayMainFrameBackpack"):IsShown() then
	-- 	if self.update.backpackShown == false then
	-- 		needUpdate = true;
	-- 	end
	-- else
	-- 	if self.update.backpackShown == true then
	-- 		needUpdate = true;
	-- 	end
	-- end

	--刷新
	-- state = self:GetCurToolState();
	-- if self.update.oldState ~= state or self.update.oldToolMode ~= curToolMode or needUpdate then
	-- 	self.update.oldState = state;
	-- 	self.update.oldToolMode = curToolMode;

	-- 	self.view:Refresh(curToolMode, state);				--刷新摆块提示
	-- end

	----
	-- if getglobal("PlayShortcut"):IsShown() then
	-- 	self.update.shortcutShown = true;
	-- else
	-- 	self.update.shortcutShown = false;
	-- end

	-- if getglobal("PlayMainFrameBackpack"):IsShown() then
	-- 	self.update.backpackShown = true;
	-- else
	-- 	self.update.backpackShown = false;
	-- end
end

--获取当前工具的状态
function ToolModeFrameCtrl:GetCurToolState()
	local curToolMode = self.curToolMode;
	local state = 0;

	if curToolMode == 1 then
		state = TriggerObjLibMgr:getAreaState();
	elseif curToolMode == 2 then
		
	elseif curToolMode == 3 then
		state = LivingToolMgr:getSelectType();
		if state == 1 then
			--插件库中选择
			state = 0;
		else
			state = LivingToolMgr:getState();
		end
	elseif curToolMode == 4 then
		state = TriggerObjLibMgr:GetDisplayBoardMappingState();
	end

	return state;
end

--是否是使用模式
function ToolModeFrameCtrl:IsUseMode()
	local param = self.model:GetIncomingParam();

	if param and param.strOpenType and param.strOpenType == "trigger" then
		return true;
	end

	return false;
end

--是否可以切换工具模式
function ToolModeFrameCtrl:CanSwitchToolMode()
	local canSwitch = true;

	if self:IsUseMode() then
		--使用模式
		canSwitch = false;
	else
		--编辑模式
		local state = self:GetCurToolState();
		local curToolMode = self.curToolMode;

		if curToolMode == 1 then
			if state == 8 then
				canSwitch = true;
			else
				canSwitch = false;
			end
		elseif curToolMode == 3 then
			if state == 0 then
				canSwitch = true;
			else
				canSwitch = false;
			end

			if IsUIFrameShown("DeveloperResourceLib") then
				canSwitch = false;
			end
		end
	end
	
	return canSwitch;
end

--启动
function ToolModeFrameCtrl:Start()

end

--重置
function ToolModeFrameCtrl:Reset()
	if IsUIFrameShown("DeveloperResourceLib") then
		GetInst("UIManager"):Close("DeveloperResourceLib");
	end
end 

--刷新
function ToolModeFrameCtrl:Refresh()
	print("ToolModeFrameCtrl:Refresh:");
	if ClientCurGame and ClientCurGame:isInGame() then
		print("in game");
	else
		print("not in game");
		return;
	end
	
	self.update.oldToolMode = 0;
	self.update.oldState = 0;

	if CurWorld and CurWorld:isGameMakerToolMode() then
		--如果是工具模式, curToolMode:获取当前模式
		self.curToolMode = CurWorld:getToolModeCurType();
		if self.curToolMode == TOOL_MODE_DISPLAYBOARD then
			self.curToolMode = 4;
		end
		print("ToolModeFrameCtrl:Refresh curToolMode = "..self.curToolMode);
	else
		self.curToolMode = TOOL_MODE_NONE;
	end

	
	local state = self:GetCurToolState();
	self.view:Refresh(self.curToolMode, state, LivingToolMgr:getSelectType(), self:IsUseMode());
	self.view:UpdateLivesToolType(LivingToolMgr:getSelectType())
	self.view:UpdatePreviewFrame(self.curToolMode, 0, 0, 0);

	--显示按钮状态
	local showbtnState = self:GetShowBtnState();
	self.view:UpdateShowBtnState(showbtnState);
	--生物特效显示
	if showbtnState == self.view.showbtnState.show_open then
		LivingToolMgr:showAllPreviewLives(true);
	else
		if self.curToolMode > TOOL_MODE_NONE then
			LivingToolMgr:showAllPreviewLives(true);
		else
			LivingToolMgr:showAllPreviewLives(false);
		end
	end

	--使用模式, 隐藏工具模式按钮
	-- if self:IsUseMode() then
	-- 	getglobal("ToolModeFrameToolModeBtn"):Hide();
	-- end
	self.view:DisplayBoardVisible();
end

--点击进入/退出工具模式按钮
function ToolModeFrameCtrl:ToolModeBtnClick()
	if CurWorld and CurWorld:isGameMakerToolMode() == true then
		--退出工具模式
		CurWorld:quitToolMode();
		self.curToolMode = TOOL_MODE_NONE;
		local state = self:GetCurToolState();
		self.view:Refresh(self.curToolMode, state, nil, self:IsUseMode());

		if getglobal("ToolObjLib"):IsShown() then
			GetInst("UIManager"):Close("ToolObjLib");
		end

		-- local staTime = getkv("last_quit_developerTool_timeStatistics") or 0
		-- local nowTime = os.date("%d", AccountManager:getSvrTime())
		-- if nowTime ~= staTime then
		-- 	statisticsGameEventNew(52014, 2, AccountManager:getUin())
		-- 	setkv("last_quit_developerTool_timeStatistics", nowTime)
		-- end
	else
		--进入工具模式
		CurWorld:gotoToolMode(TOOL_MODE_AREA);
		self.curToolMode = TOOL_MODE_AREA;
		local state = self:GetCurToolState();
		self.view:Refresh(self.curToolMode, state, nil, self:IsUseMode());
		
		--[[进入工具模式上报]]
		local staTime = getkv("last_into_developerTool_timeStatistics") or 0
		local nowTime = os.date("%d", AccountManager:getSvrTime())
		if nowTime ~= staTime then
			statisticsGameEventNew(52014, 1, AccountManager:getUin())
			setkv("last_into_developerTool_timeStatistics", nowTime)
		end
	end
end

--回滚按钮点击
function ToolModeFrameCtrl:RevertBtnClick()
	if CurWorld and CurWorld:isGameMakerToolMode() == true then
		local curToolMode = self.curToolMode;

		if curToolMode == TOOL_MODE_AREA then
			if TriggerObjLibMgr:AreaRevert() then
				--区域, 回滚成功
			end
		elseif curToolMode == TOOL_MODE_ACTOR then
			--生物, 回滚成功
			if LivingToolMgr:cancelSelect() then
				--区域, 回滚成功
			end
		elseif curToolMode == 4 then
			local revokeResult = TriggerObjLibMgr:RevokeDisplayBoard();
		end

		local state = self:GetCurToolState();
		self.view:Refresh(curToolMode, state, LivingToolMgr:getSelectType(), self:IsUseMode());
	end
end

--工具按钮点击, 切换工具类型
function ToolModeFrameCtrl:ToolBtnClick(id)
	print("ToolModeFrameCtrl:ToolBtnClick: id = ", id);
	if not self:CanSwitchToolMode() then
		print("can not switch toolmode:");
		return;
	end

	--如果当前是生物工具, 且是创建模式, 则释放当前抓取的生物
	if self.curToolMode == TOOL_MODE_ACTOR then
		LivingToolMgr:cancelSelect();
	end

	local index = id or this:GetClientID();
	
	if CurWorld then 
		if index == 1 then
			--1. 区域模式
			CurWorld:gotoToolMode(TOOL_MODE_AREA);
		elseif index == 2 then
			CurWorld:gotoToolMode(TOOL_MODE_POINT);
		elseif index == 3 then
			CurWorld:gotoToolMode(TOOL_MODE_ACTOR);
		elseif index == 4 then --显示板
			CurWorld:gotoToolMode(TOOL_MODE_DISPLAYBOARD);
		end
	end

	self.curToolMode = index;
	local state = self:GetCurToolState();
	self.view:Refresh(index, state, LivingToolMgr:getSelectType(), self:IsUseMode());
	--生物工具
    if index == TOOL_MODE_ACTOR then
        self.view:UpdateLivesToolType(LivingToolMgr:getSelectType())
    end
end

--对象库按钮点击: 打开对象库
function ToolModeFrameCtrl:ObjLibClick()
	print("ToolModeFrameCtrl:ObjLibClick:");

	--如果是从触发器进来的, 那么打开对象库应该是使用模式
	if self:IsUseMode() then
		local param = self.model:GetIncomingParam();
		local objLibParam = param.objLibParam;

		if objLibParam then
			print("open from trigger:");
			if self.curToolMode == TOOL_MODE_ACTOR then
				LivingToolMgr:cancelSelect()
			end

			GetInst("UIManager"):Open("ToolObjLib", objLibParam);
			return;
		end
	end

	local callback = function(strOpType, tabIndex ,iscreate)
		print("callback: strOpType = ", strOpType, ", tabIndex = ", tabIndex);
		if strOpType and string.find(strOpType, "CreateClick") then
			self:ToolBtnClick(tabIndex);
		end
		if tabIndex and tabIndex == 3 then
			if iscreate then
				self:ActorCreateClick()
			else
				self:ActorSelect()
			end
		end
	end

	if getglobal("ToolObjLib"):IsShown() then
		GetInst("UIManager"):Close("ToolObjLib", param);
	else
		local param = {};
		param.useType = 1;
		param.callback = callback;
		GetInst("UIManager"):Open("ToolObjLib", param);
	end
end

--生物选择
function ToolModeFrameCtrl:ActorSelect()
	self.view:UpdateLivesToolType(TOOL_SELECT_TYPE_WORLD)
	LivingToolMgr:setSelectType(TOOL_SELECT_TYPE_WORLD)
	print("ToolModeFrameCtrl:ActorSelect:");
	if not CurMainPlayer:isSightMode() then
		CurMainPlayer:setSightMode(true);
	end
end

--新建生物
function ToolModeFrameCtrl:ActorCreateClick()
	LivingToolMgr:setSelectType(TOOL_SELECT_TYPE_MOD)
	local callback = function(ID)
		print("callback: ID = ", ID);
		LivingToolMgr:setSelectObjIDFromMod(ID)
		if not CurMainPlayer:isSightMode() then
			CurMainPlayer:setSightMode(true);
		end
		self.view:UpdateTip(self.curToolMode, self:GetCurToolState())
	end
	self.view:UpdateLivesToolType(TOOL_SELECT_TYPE_MOD)
	local param = {};
	local useLibrary = 4;
	param.useLibrary = useLibrary;
	param.callback = callback;
	param.sstype = {modpacketid = "",modlib = false}
	GetInst("UIManager"):Open("DeveloperResourceLib", param);
	-- 打开新建模式的选择ui 取消当前选择
	LivingToolMgr:cancelSelect()
end

--显示/隐藏按钮点击
function ToolModeFrameCtrl:ShowBtnClick()
	local showbtnState = self:GetShowBtnState();

	if showbtnState == self.view.showbtnState.show_open then
		TriggerObjLibMgr:setShowEffectState(false);
		self.view:UpdateShowBtnState(self.view.showbtnState.show_close);
		ShowGameTips(GetS(14537), 3);
	else
		TriggerObjLibMgr:setShowEffectState(true);
		self.view:UpdateShowBtnState(self.view.showbtnState.show_open);
		ShowGameTips(GetS(14538), 3);
	end

	--生物特效显示
	if showbtnState == self.view.showbtnState.show_open then
		LivingToolMgr:showAllPreviewLives(false);
	else
		LivingToolMgr:showAllPreviewLives(true);
	end
end

--刷新显示/隐藏按钮状态
function ToolModeFrameCtrl:GetShowBtnState()
	-- print("ToolModeFrameCtrl:GetShowBtnState:");
	local curToolMode = self.curToolMode;
	local bShowEffect = TriggerObjLibMgr and TriggerObjLibMgr:getShowEffectState() or false;
	local showbtnState = self.view.showbtnState.hide;

	-- print("curToolMode = ", curToolMode, ", bShowEffect = ", bShowEffect);

	if curToolMode == TOOL_MODE_NONE then
		if bShowEffect then
			showbtnState = self.view.showbtnState.show_open;
		else
			showbtnState = self.view.showbtnState.show_close;
		end
	else
		showbtnState = self.view.showbtnState.hide;
	end

	return showbtnState;
end

