--声明
local ToolModeFrameModel = Class("ToolModeFrameModel",ClassList["UIBaseModel"])

--创建
function ToolModeFrameModel:Create(param)
	return ClassList["ToolModeFrameModel"].new(param)
end

--初始化
function ToolModeFrameModel:Init()
	
end

--重置
function ToolModeFrameModel:ReSet()
	
end



