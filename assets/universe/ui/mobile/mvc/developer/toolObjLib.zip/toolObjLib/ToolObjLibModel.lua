--声明
local ToolObjLibModel = Class("ToolObjLibModel",ClassList["UIBaseModel"])

--创建
function ToolObjLibModel:Create(param)
	return ClassList["ToolObjLibModel"].new(param)
end

--初始化
function ToolObjLibModel:Init()
	self.data.LibData = {
		{	--1. 区域
			nType = 1,
			defList = {
				--def1, def2, ...
			},
		},
		{	--2. 位置
			nType = 2,
			defList = {},
		},
		{	--3. 生物
			nType = 3,
			defList = {},
		},
		{	--4. 生物
			nType = 4,
			defList = {},
		},
	};
end

--重置
function ToolObjLibModel:ReSet()

end

--获取对象库
function ToolObjLibModel:GetLibData()
	return self.data.LibData;
end

--根据类型得到库数据
function ToolObjLibModel:GetLibDataByType(nType)
	--nType: 1: 区域 2: 位置 3: 生物 4:显示板
	print("GetLibDataByType: nType = ", nType);
	for i = 1, #self.data.LibData do
		if self.data.LibData[i].nType == nType then
			print('OK:');
			return self.data.LibData[i];
		end
	end

	return nil;
end

--加载数据
function ToolObjLibModel:Load()
	self:LoadArea();
	self:LoadPosition();
	self:LoadActor();
	self:LoadDisplayBoard();
end

--加载区域
function ToolObjLibModel:LoadArea()
	print("LoadArea:");
	local count = TriggerObjLibMgr:getAreaCount();
	self.data.LibData[1].defList = {};

	print("count = ", count);

	for i = 1, count do
		local def = TriggerObjLibMgr:getAreaDataByIndex(i);
					
		if def then
			print("ok: i = ", i);
			print(def.uuid);
			print(def.name);
			table.insert(self.data.LibData[1].defList, def);
		end
	end
end

--加载位置
function ToolObjLibModel:LoadPosition()
	print("LoadPosition:");

	local count = TriggerObjLibMgr:getPositionCount();
	self.data.LibData[2].defList = {};

	print("count = ", count);

	for i = 1, count do
		local def = TriggerObjLibMgr:getPositionByIndex(i);
					
		if def then
			print("ok: i = ", i);
			print(def.uuid);
			print(def.name);
			table.insert(self.data.LibData[2].defList, def);
		end
	end
end

--加载生物
function ToolObjLibModel:LoadActor()
	print("LoadActor:");

	local count = LivingToolMgr:getAllLivingToolNumber();
	self.data.LibData[3].defList = {};

	print("count = ", count);

	for i = 1, count do
		local def = LivingToolMgr:getLivingToolByIndex(i - 1);
					
		if def then
			print("ok: i = ", i);
			print(def.uuid);
			print(def.name);
			table.insert(self.data.LibData[3].defList, def);
		end
	end
end

--加载显示板
function ToolObjLibModel:LoadDisplayBoard()
	print("LoadDisplayBoard:");

	local count = TriggerObjLibMgr:GetDisplayBoardCount();
	self.data.LibData[4].defList = {};
	print("count = ", count);

	for i = 1, count do
		local def = TriggerObjLibMgr:GetDisplayBoardByIndex(i - 1);
		if def then
			print("LoadDisplayBoard ok: i = ", i, ", uuid = ", def.uuid, ", name = ", def.name);
			table.insert(self.data.LibData[4].defList, def);
		end
	end
end

--根据index获取def
function ToolObjLibModel:GetItemDefByIndex(nType, nItemIndex)
	print("ToolObjLibModel:GetItemDefByIndex: nType = ", nType, ", nItemIndex = ", nItemIndex);
	local LibData = self:GetLibDataByType(nType);

	if LibData then
		for i = 1, #LibData.defList do
			if i == nItemIndex then
				local def = LibData.defList[i];
				return def;
			end
		end
	end

	return nil;
end

--删除数据
-- nType: 类型(如:1:区域) nItemIndex: item索引
function ToolObjLibModel:DeleteItemByIndex(nType, nItemIndex)
	print("ToolObjLibModel:DeleteItemByIndex: nType = ", nType, ", nItemIndex = ", nItemIndex);

	-- local LibData = self:GetLibDataByType(nType);

	local def = self:GetItemDefByIndex(nType, nItemIndex);

	if def then
		print("deleft successful:");
		if nType == 1 then
			--1. 删除区域
			TriggerObjLibMgr:DeleteArea(def.uuid);
			--重新加载
			self:LoadArea();
		elseif nType == 2 then
			--2. 删除位置
			TriggerObjLibMgr:DeletePosition(def.uuid);
			self:LoadPosition();
		elseif nType == 3 then
			--3. 删除生物
			LivingToolMgr:deleteLivingTool(def.uuid);
			self:LoadActor();
		elseif nType == 4 then
			--4. 删除显示板
			TriggerObjLibMgr:DeleteDisplayBoard(def.uuid);
			self:LoadDisplayBoard();
		end
	end
end

--改名, 参数同上
function ToolObjLibModel:ModifyNameByIndex(nType, nItemIndex, newName)
	print("ToolObjLibModel:ModifyNameByIndex: nType = ", nType, ", nItemIndex = ", nItemIndex, ", newName = " .. newName);

	local def = self:GetItemDefByIndex(nType, nItemIndex);

	if def then
		print("modify successful:");
		if nType == 1 then
			TriggerObjLibMgr:ModifyAreaNameByUUID(def.uuid, newName);
			self:LoadArea();
		elseif nType == 2 then
			TriggerObjLibMgr:ModifyPositionNameByUUID(def.uuid, newName);
			self:LoadPosition();
		elseif nType == 3 then
			LivingToolMgr:setLivingToolName(def.uuid, newName);
			self:LoadActor();
		elseif nType == 4 then
			local displayBoardData = TriggerObjLibMgr:GetDisplayBoardByUUID(def.uuid);
			displayBoardData.name = newName;
			self:LoadDisplayBoard();
		end
	end
end

--重摆, 参数同上
function ToolObjLibModel:ReplaceItemByIndex(nType, nItemIndex)
	print("ToolObjLibModel:ReplaceItemByIndex: nType = ", nType, ", nItemIndex = ", nItemIndex);

	local def = self:GetItemDefByIndex(nType, nItemIndex);

	if def then
		print("modify successful:");
		if nType == 1 then
			TriggerObjLibMgr:AreaReplace(def.uuid);
			-- self:LoadArea();
		elseif nType == 2 then

		elseif nType == 3 then

		elseif nType == 4 then
			if def and TriggerObjLibMgr and TriggerObjLibMgr.RefreshDisplayBoardByUUid then
				TriggerObjLibMgr:ResetDisplayBoardPos(def.uuid);
				self:LoadDisplayBoard();
			end
		end
	end
end
