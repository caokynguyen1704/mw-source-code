--声明
local ToolObjLibCtrl = Class("ToolObjLibCtrl",ClassList["UIBaseCtrl"])

--创建
function ToolObjLibCtrl:Create(param)
	print("ToolObjLibCtrl:Create:");
	return ClassList["ToolObjLibCtrl"].new(param)
end

--初始化
function ToolObjLibCtrl:Init(param)
	print("ToolObjLibCtrl:Init:");
	--界面常量定义
	self.data = {};
	self.data.curLibData = nil;
	self.data.curTabIndex = 1;
	self.data.curItemIndex = 0;

	self.data.chooseAreaID = 230001;
	self.data.choosePosID = 240003;
	self.data.chooseActorID = 300003;
	self.data.chooseDisplayBoard = 590001;

	--打开类型: 1. 编辑 2. 选择
	self.data.curUseType = 1;

	--加载对象库

	--改名输入框
	self.nameInput = {
		frame = getglobal("ToolObjLibNameInput"),
		edit  = getglobal("ToolObjLibNameInputContentEdit"),
		seq = 0;
		callback = nil;
	};

	--对象空为空时显示的提示文字
	self.define.emptyString = {
		14532,14533,14534,14543
	}
end

--启动
function ToolObjLibCtrl:Start()
	
end

--重置
function ToolObjLibCtrl:Reset()
	print("ToolObjLibCtrl:Reset:");
	--如果是使用模式, 则关闭界面时, 退出工具模式
	-- local curUseType = self.data.curUseType;
	-- if curUseType and curUseType > 1 then
	-- 	CurWorld:quitToolMode();
	-- 	GetInst("UIManager"):Open("ToolModeFrame");
	-- 	local param = self.model:GetIncomingParam();
	-- end
	self.view:UpdateItemNum();
end


--刷新
function ToolObjLibCtrl:Refresh()
	--param:
	--[[
		param = {
			useType = 1, 			--1: 编辑模式, 工具模式进入 2: 使用模式采用, 表示选择的库类型: 230001: 选择区域 240003:选择位置 300003:选择生物
			callback = function, 	--使用模式用, 回调函数
		},	
	]]	
	print("ToolObjLibCtrl:Refresh")
	self.view:DisplayBoardVisible();

	local param = self.model:GetIncomingParam() or {useType = 1,};
	local useType = param.useType;
	print("param = ", param);
	self.data.curUseType = useType;

	--常量初始化
	self.data.curLibData = nil;
	self.data.curTabIndex = 1;
	self.data.curItemIndex = 0;
	
	--加载数据
	self.model:Load();
	local LibData = self.model:GetLibData();
	self.data.curLibData = LibData;

	--使用模式, 则隐藏工具面板, 并进入使用模式
	if useType and useType > 1 then
		CurWorld:gotoToolMode(TOOL_MODE_USE);
		GetInst("UIManager"):Close("ToolModeFrame");

		if useType == self.data.chooseAreaID then
			self.data.curTabIndex = 1;
		elseif useType == self.data.choosePosID then
			self.data.curTabIndex = 2;
		elseif useType == self.data.chooseActorID then
			self.data.curTabIndex = 3;
		elseif useType == self.data.chooseDisplayBoard then
			self.data.curTabIndex = 4;
		end
	end

	local tapType = nil;
	if param.tapType ~= nil and type(param.tapType) == "number" then
		tapType = param.tapType;
		self.data.curTabIndex = tapType;
	end

	--刷新界面
	self.view:Refresh(LibData, self.data.curUseType, tapType, param.isMiniClub);

	--关闭菜单
	if getglobal("ToolObjLibBodyHandle"):IsShown() then
		getglobal("ToolObjLibBodyHandle"):Hide();
	end

	--隐藏快捷栏
	if getglobal("PlayShortcut"):IsShown() then
		getglobal("PlayShortcut"):Hide();
	end
	if getglobal("PlayMainFrameBackpack"):IsShown() then
		getglobal("PlayMainFrameBackpack"):Hide();
	end

	if tapType ~= nil and type(tapType) == "number" then
		self.view:ScrollListEnd(tapType);
	end
end

--关闭按钮
function ToolObjLibCtrl:CloseBtnClick()
	GetInst("UIManager"):Close(self.define.uiName);

	local param = self.model:GetIncomingParam();
	
	if param then
		local useType = param.useType;
		if useType and useType > 1 then
			print("call back:");
			--退出使用模式
			CurWorld:gotoToolMode(TOOL_MODE_NONE);

			local callback = param.callback;
			if callback then
				callback(0);
			end
		end
		
		-- MiniClub回调 
		if param.isMiniClub and param.musicClubCb then 
			param.musicClubCb()
		end
	end
end

--tab按钮点击
function ToolObjLibCtrl:TopTabBtnClick()
	--index: 1: 区域 2: 位置 3: 生物 4: 显示板
	local index = this:GetClientID();
	
	self.data.curTabIndex = index;
	self.data.curItemIndex = 0;
	self.view:UpdateTabBtn(index);
end

--条目点击
function ToolObjLibCtrl:ItemClick()
	print("ToolObjLibCtrl:ItemClick:");
	local index = this:GetClientID()+1;
	print("index = ", index);
	
	self.data.curItemIndex = index;

	if self.data.curTabIndex == 1 then
		--1. 点击区域Item
		self:ItemClick_Area(index);
	elseif self.data.curTabIndex == 2 then
		--2. 点击位置Item
		self:ItemClick_Position(index);
	elseif self.data.curTabIndex == 3 then
		--3. 点击生物Item
		self:ItemClick_Actor(index);
	elseif self.data.curTabIndex == 4 then
		--4.点击显示板Item
		self:ItemClick_DisplayBoard(index);
	end

	--刷新条目高亮
	self.view:UpdateChecked(self.data.curTabIndex, index);
end

--点击区域条目
function ToolObjLibCtrl:ItemClick_Area(index)
	print("ToolObjLibCtrl:ItemClick_Area:");
	local ItemLibData = self.model:GetLibDataByType(1);

	if ItemLibData and ItemLibData.defList then
		print("111:");
		
		for i = 1, #ItemLibData.defList do
			print("i = ", i);
			local def = ItemLibData.defList[i];

			if i == index then
				print("checked:");
				if def then
					--选中: 15
					TriggerObjLibMgr:SetAreaColorId(def.uuid, 18);

					--移动玩家
					-- player:gotoBlockPos(def.myPos);
					CurMainPlayer:gotoBlockPos(def.myPos);
				end
			else
				print("not checked:");
				if def then
					--未选中: 8
					TriggerObjLibMgr:SetAreaColorId(def.uuid, 17);
				end
			end
		end
	end
end

--点击位置条目
function ToolObjLibCtrl:ItemClick_Position(index)
	print("ToolObjLibCtrl:ItemClick_Position:");
	local ItemLibData = self.model:GetLibDataByType(2);

	if ItemLibData and ItemLibData.defList then
		print("111:");
		
		for i = 1, #ItemLibData.defList do
			print("i = ", i);
			local def = ItemLibData.defList[i];

			if i == index then
				print("checked:");
				if def then
					--移动玩家
					CurMainPlayer:gotoBlockPos(def.myPos);
				end
			end
		end
	end
end

--点击生物条目
function ToolObjLibCtrl:ItemClick_Actor(index)
	print("ToolObjLibCtrl:ItemClick_Actor:");
	local ItemLibData = self.model:GetLibDataByType(3);

	if ItemLibData and ItemLibData.defList then
		print("111:");
		
		for i = 1, #ItemLibData.defList do
			print("i = ", i);
			local def = ItemLibData.defList[i];

			if i == index then
				print("checked:");
				if def then
					--移动玩家
					-- player:gotoBlockPos(def.position);
					LivingToolMgr:gotoLivingPos(def.uuid);
				end
			end
		end
	end
end

--点击显示板条目
function ToolObjLibCtrl:ItemClick_DisplayBoard(index)
	print("ToolObjLibCtrl:ItemClick_DisplayBoard:");
	local ItemLibData = self.model:GetLibDataByType(4);

	if not ItemLibData or not ItemLibData.defList then
		return;
	end

	for i = 1, #ItemLibData.defList do
		local def = ItemLibData.defList[i];

		if i == index and def then
			self:ShowDisplayBoardProperty(def.mapid, def.uuid);
			TriggerObjLibMgr:ResetPlayerPositionByUUid(def.uuid);
		end
	end

	self.view:CloseSetMenu();
end

function ToolObjLibCtrl:ShowDisplayBoardProperty(mapid, uuid)
	Log("ShowDisplayBoardProperty click");

	GetInst("MiniUIManager"):AddPackage({"miniui/miniworld/common", "miniui/miniworld/common_comp","miniui/miniworld/UIEditor"});
	GetInst("MiniUIManager"):OpenUI("DisplayBoardMain", "miniui/miniworld/ugc_displayboard", "DisplayBoardMainAutoGen", {mapid, uuid});
	local displayBoardMainAutoGen = GetInst("MiniUIManager"):GetUI("DisplayBoardMainAutoGen");
	if not displayBoardMainAutoGen or not displayBoardMainAutoGen.ctrl then
		return
	end

	if displayBoardMainAutoGen.ctrl.RefreshDisplayBoard then
		displayBoardMainAutoGen.ctrl:RefreshDisplayBoard({mapid, uuid})
	end
	if displayBoardMainAutoGen.ctrl.ChangeSideClick then
		displayBoardMainAutoGen.ctrl:ChangeSideClick(1);
	end
end

--点击关闭设置菜单
function ToolObjLibCtrl:CloseHandleFrame()
	self.view:CloseSetMenu();
end

--设置按钮点击: 打开设置菜单
function ToolObjLibCtrl:ItemSetBtnClick()
	if getglobal("ToolObjLibBodyHandle"):IsShown() then
		self.view:CloseSetMenu();
	else
		local index = this:GetParentFrame():GetClientID() + 1;
		local curTabIndex = self.data.curTabIndex;
		self.data.curItemIndex = index;
		self.view:OpenSetMenu(curTabIndex, index);
	end
	
end

--弹出菜单条目点击: 1: 改名 2: 删除 3: 重摆
function ToolObjLibCtrl:MenuItemClick(id)
	print("ToolObjLibCtrl:DeleteItenClick:");
	local curTabIndex = self.data.curTabIndex;
	local curItemIndex = self.data.curItemIndex;
	local bRet = false;
	print("curItemIndex = ", curItemIndex);

	if id == 1 then
		--改名
		if curTabIndex == 4 then
			self.view:UpdateChecked(curTabIndex, curItemIndex);
			self:ItemClick_DisplayBoard(curItemIndex);
		else
			local type, newName = self:InputNewName();
			if type == 1 then
				self.model:ModifyNameByIndex(curTabIndex, curItemIndex, newName);
				bRet = true;
			end
		end
	elseif id == 2 then
		--删除
		self.model:DeleteItemByIndex(curTabIndex, curItemIndex);
		bRet = true;
	elseif id == 3 then
		--重摆
		local nToolModeType = self.data.curTabIndex;
		if nToolModeType == 1 then
			CurWorld:gotoToolMode(TOOL_MODE_AREA);
		elseif nToolModeType == 2 then
			CurWorld:gotoToolMode(TOOL_MODE_POINT);
		elseif nToolModeType == 3 then
			CurWorld:gotoToolMode(TOOL_MODE_ACTOR);
		elseif nToolModeType == 4 then --显示板
			CurWorld:gotoToolMode(TOOL_MODE_DISPLAYBOARD);
		end
		self.model:ReplaceItemByIndex(curTabIndex, curItemIndex);
		if curTabIndex == 1 then
			self:ItemClick_Area(curItemIndex);
		elseif curTabIndex == 4 then
			
		end
		bRet = true;
		GetInst("UIManager"):Close(self.define.uiName);
		return;--********************************
	end
	
	if bRet then
		getglobal("ToolObjLibBodyHandle"):Hide();
		-- self.model:Load();
		local LibData = self.model:GetLibData();
		self.data.curLibData = LibData;
		self.view:Refresh(LibData, self.data.curUseType, curTabIndex);
		if (id == 2) then
			self.view:DeleteCheckItem();
		else
			self.view:RefreshCheckItem();
		end
		-- self.view:UpdateTabBtn(curTabIndex);
	end
end

--名字输入框------------------------------------------------------------
function ToolObjLibCtrl:InputNewName()
	print("ToolObjLibCtrl:InputNewName:");
	local seq = gen_gid();
	self.nameInput.seq = seq;
	self.nameInput.callback = callback;
	self.nameInput.frame:Show();
	self.nameInput.edit:Clear();
	UIFrameMgr:setCurEditBox(self.nameInput.edit);

	--等待输入
	print("wait...");
	local _timeout = 1000;
	local code, ret = threadpool:wait(seq, _timeout);
	
	--等待完成, 结果
	--[[
		ret = {
			newName = "新名字",
			type = 1,			--类型: 1: OK 2:cancel
		},
	]]
	
	self.nameInput.frame:Hide();
	print("over:");
	print(ret);
	local type = ret.type;
	local newName = ret.newName;

	return type, newName;
end

--确认按钮点击
function ToolObjLibCtrl:NameInput_OkBtnClick()
	print("NameInput_OkBtnClick:");
	local _newName = self.nameInput.edit:GetText();
	local seq = self.nameInput.seq;

	if seq and _newName and _newName ~= "" then
		--敏感词
		_newName = ReplaceFilterString(_newName);

		local ret = {newName = _newName, type = 1};
		threadpool:notify(seq, ErrorCode.OK, ret);
	end
end

--取消按钮点击
function ToolObjLibCtrl:NameInput_CancelBtnClick()
	local seq = self.nameInput.seq;
	
	if seq then
		local ret = {type = 2};
		threadpool:notify(seq, ErrorCode.OK, ret);
	end

	self.nameInput.frame:Hide();
end
-----------------------------------------------------------------------

--确定按钮
function ToolObjLibCtrl:ItemOkBtnClick()
	print("ToolObjLibCtrl:ItemOkBtnClick:");
	local index = this:GetParentFrame():GetClientID()+1;
	local curTabIndex = self.data.curTabIndex;
	print("index = ", index);

	--退出使用模式
	CurWorld:gotoToolMode(TOOL_MODE_NONE);

	local def = self.model:GetItemDefByIndex(curTabIndex, index);
	if def then
		local uuid = def.uuid;

		--回调
		local param = self.model:GetIncomingParam();
		if param and param.callback then
			print("call back:");
			local callback = param.callback;
			callback(uuid);
		end
		
		-- MiniClub回调 
		if param and param.isMiniClub and param.musicClubCb then 
			param.musicClubCb(def)
		end 
	end

	GetInst("UIManager"):Close(self.define.uiName);
end

--选择按钮点击
function ToolObjLibCtrl:SelectBtnClick()
	GetInst("UIManager"):Close(self.define.uiName);

	local objLibParam = self.model:GetIncomingParam() or {useType = 1,};
	local useType = objLibParam.useType;

	if useType > 1 then
		--是从触发器进来的, 需要进入工具模式, 进入选择流程
		local nToolModeType = self.data.curTabIndex;
		if nToolModeType == 1 then
			CurWorld:gotoToolMode(TOOL_MODE_AREA);
		elseif nToolModeType == 2 then
			CurWorld:gotoToolMode(TOOL_MODE_POINT);
		elseif nToolModeType == 3 then
			CurWorld:gotoToolMode(TOOL_MODE_ACTOR);
		elseif nToolModeType == 4 then --显示板
			CurWorld:gotoToolMode(TOOL_MODE_DISPLAYBOARD);
		end
		local param = {};
		param.disableOperateUI = true;
		param.objLibParam = objLibParam;	--透传
		param.strOpenType = "trigger";		--打开类型: 触发器
		print("ToolObjLibCtrl:CreateBtnClick:");
		GetInst("UIManager"):Open("ToolModeFrame", param);

		if self.data.curTabIndex == 3 then
			--如果是生物, 需要打开素材库选择界面
			press_btn("ToolModeFrameActorSelect");
		end
	else
		if objLibParam and objLibParam.callback then
			objLibParam.callback("CreateClick", self.data.curTabIndex);
		end
	end
end

--新建按钮点击
function ToolObjLibCtrl:CreateBtnClick()
	print("ToolObjLibCtrl:CreateBtnClick:");
	GetInst("UIManager"):Close(self.define.uiName);

	local objLibParam = self.model:GetIncomingParam() or {useType = 1};
	local useType = objLibParam.useType;
	local nToolModeType = self.data.curTabIndex;

	print("objLibParam:");
	print(objLibParam);

	if useType > 1 then
		--是从触发器进来的, 需要进入工具模式, 进入创建流程
		print("111:");
		if nToolModeType == 1 then
			CurWorld:gotoToolMode(TOOL_MODE_AREA);
		elseif nToolModeType == 2 then
			CurWorld:gotoToolMode(TOOL_MODE_POINT);
		elseif nToolModeType == 3 then
			CurWorld:gotoToolMode(TOOL_MODE_ACTOR);
		elseif nToolModeType == 4 then --显示板
			CurWorld:gotoToolMode(TOOL_MODE_DISPLAYBOARD);
		end
		local param = {};
		param.disableOperateUI = true;
		param.objLibParam = objLibParam;	--透传
		param.strOpenType = "trigger";		--打开类型: 触发器
		print("ToolObjLibCtrl:CreateBtnClick:");
		GetInst("UIManager"):Open("ToolModeFrame", param);

		if self.data.curTabIndex == 3 then
			--如果是生物, 需要打开素材库选择界面
			press_btn("ToolModeFrameActorCreate");
		end
	else
		--切换到对应的工具
		if objLibParam and objLibParam.callback then
			objLibParam.callback("CreateClick", nToolModeType, true)
		end
	end
end


function ToolObjLibCtrl:tableCellAtIndex(tableView,index)
	return self.view:tableCellAtIndex(tableView,index)
end

function ToolObjLibCtrl:numberOfCellsInTableView(tableView)
	return self.view:numberOfCellsInTableView(tableView)
end

function ToolObjLibCtrl:tableCellSizeForIndex(tableView,index)
	return self.view:tableCellSizeForIndex(tableView,index)
end