--声明
local ToolObjLibView = Class("ToolObjLibView",ClassList["UIBaseView"])

--创建
function ToolObjLibView:Create(param)
	return ClassList["ToolObjLibView"].new(param)
end

--初始化
function ToolObjLibView:Init()
	print("ToolObjLibView:Init:");

	--标题栏
	self:GetChild("BodyTitleFrameName"):SetText(GetS(14505));

	self.data = {};

	--当前选中的tab
	self.data.curTabIndex = 1;

	--当前的对象库
	self.data.curLibData = {};

	--类型
	self.data.curUseType = 1;

	--顶部tab按钮
	self.data.topTab = {
		{
			btnNameID = 14522,	--按钮名:区域
			useType = 230001,
			btn = nil,			--按钮控件对象
			btnname = nil,		--名字控件对象
			checked = nil,		--高亮
		},
		{
			btnNameID = 14523,	--按钮名:位置
			useType = 240003,
			btn = nil,
		},
		{
			btnNameID = 14524,	--按钮名:生物
			useType = 300003,
			btn = nil,
		},
		{
			btnNameID = 14539,	--按钮名:显示板
			useType = 590001,
			btn = nil,
		},
	};

	--创建和选择按钮
	self.data.CreateBtn = self:GetChild("BodyCreateBtn");
	self.data.CreateBtn_Font = self:GetChild("BodyCreateBtnName");
	self.data.CreateBtn_Font:SetFontSize(24);
	self.data.SelectBtn = self:GetChild("BodySelectBtn");
	self.data.SelectBtn_Font = self:GetChild("BodySelectBtnName");
	self.data.SelectBtn_Font:SetFontSize(24);
	self.emptyFont = getglobal("ToolObjLibBodyEmptyText")
	--item对象
	self.data.itemList = {
		--item1, item2,...
	};

	--是否正在处理delete事件
	self.data.delete = false;
	--当前页面上次关闭时的item数目
	self.data.oldItemNum = {0,0,0};
	--这个记录只在当前listview里有效,checkItemOfTab记录所属index哪个tab
	self.data.checkItemIndex = nil;
	self.data.checkItemOfTab = nil;
	self.data.check = nil;
	--记录当前打开设置菜单的itemIndex
	self.data.openMenuItemIndex = nil;
	--tab按钮初始化
	for i = 1, #self.data.topTab do
		local tabbtn = self:GetChild("BodyTopBtn" .. i);
		local tabbtnname = self:GetChild("Name", tabbtn);
		local tabbtnchecked = self:GetChild("Checked", tabbtn);
		local node = self.data.topTab[i];

		tabbtn:SetPoint("left", "ToolObjLibBodyTop", "left", 8 + (i - 1) * 130, 0);
		tabbtnname:SetText(GetS(node.btnNameID));
		node.btn = tabbtn;
		node.btnname = tabbtnname;
		node.checked = tabbtnchecked;
	end

	getglobal("ToolObjLibBodyList1"):setPaddingY(10);
	getglobal("ToolObjLibBodyList2"):setPaddingY(10);
	getglobal("ToolObjLibBodyList3"):setPaddingY(10);
	getglobal("ToolObjLibBodyList4"):setPaddingY(10);
end

function ToolObjLibView:GetDisplayBoardSwitch()
	local on = false;
	if ns_version then
		on = check_apiid_ver_conditions(ns_version.display_board_switch , false)
	end
	return on;
end

--根据白名单设置显示板是否隐藏
function ToolObjLibView:DisplayBoardVisible()
	local on = self:GetDisplayBoardSwitch();

	local areaList = getglobal("ToolObjLibBodyList1");
	local areaListPlane = getglobal("ToolObjLibBodyList1Plane");
	local positionList = getglobal("ToolObjLibBodyList2");
	local positionListPlane = getglobal("ToolObjLibBodyList2Plane");
	local actorList = getglobal("ToolObjLibBodyList3");
	local actorListPlane = getglobal("ToolObjLibBodyList3Plane");
	local displayBoardList = getglobal("ToolObjLibBodyList4");
	local libBody = getglobal("ToolObjLibBody");
	local titleFrame = getglobal("ToolObjLibBodyTitleFrame");
	local top = getglobal("ToolObjLibBodyTop");
	local displayBoardBtn = getglobal("ToolObjLibBodyTopBtn4");

	if on then
		areaList:SetWidth(536);
		areaListPlane:SetWidth(536);
		positionList:SetWidth(536);
		positionListPlane:SetWidth(536);
		actorList:SetWidth(536);
		actorListPlane:SetWidth(536);
		libBody:SetWidth(536);
		titleFrame:SetWidth(536);
		top:SetWidth(536);
		displayBoardBtn:Show();
		displayBoardList:Show();
	else
		areaList:SetWidth(436);
		areaListPlane:SetWidth(436);
		positionList:SetWidth(436);
		positionListPlane:SetWidth(436);
		actorList:SetWidth(436);
		actorListPlane:SetWidth(436);
		libBody:SetWidth(436);
		titleFrame:SetWidth(436);
		top:SetWidth(436);
		displayBoardBtn:Hide();
		displayBoardList:Hide();
	end
end

--刷新
function ToolObjLibView:Refresh(LibData, useType, nToolType, isMiniClub)
	--useType: 1: 编辑 2:使用
	print("ToolObjLibView:Refresh:");
	self.data.curLibData = LibData;
	self.data.curUseType = useType or 1;

	if useType == 1 then
		--编辑模式
		self:UpdateTabBtn(nToolType);
	else
		--使用模式
		if useType == self.data.chooseAreaID then
			nToolType = 1;
		elseif useType == self.data.choosePosID then
			nToolType = 2;
		elseif useType == self.data.chooseActorID then
			nToolType = 3;
		elseif useType == self.data.chooseDisplayBoard then
			nToolType = 4;
		end

		self:UpdateTabBtn(nToolType, useType);
	end
	
	-- MiniClub隐藏位置和生物页签 
	self.data.topTab[2].btn:Show()
	self.data.topTab[3].btn:Show()
	self.isMiniClub = isMiniClub
	if isMiniClub then 
		self.data.topTab[2].btn:Hide()
		self.data.topTab[3].btn:Hide()
	end
end

--刷新tab按钮
function ToolObjLibView:UpdateTabBtn(nToolType, useType)
	--local curToolType = self.data.curTabIndex;
	local oldTabIndex = self.data.curTabIndex;
	self.data.oldItemNum[oldTabIndex] = self:GetNumberOfItem(oldTabIndex);
	self.data.curTabIndex = nToolType;
	nToolType = nToolType or 1;
	useType = useType or 1;

	if useType > 1 then
		for i = 1, #self.data.topTab do
			if useType == self.data.topTab[i].useType then
				nToolType = i;
			end
		end
	end

	for i = 1, #self.data.topTab do
		local tabbtn = self.data.topTab[i].btn;
		local tabbtnname = self.data.topTab[i].btnname;
		local tabbtnchecked = self.data.topTab[i].checked;

		if useType and useType > 1 then
			--使用模式，tab按钮不能切换
			tabbtn:Disable();
		else
			tabbtn:Enable();
		end

		if nToolType == i then
			tabbtnname:SetTextColor(76, 76, 76);
			tabbtnchecked:Show();
		else
			tabbtnname:SetTextColor(191, 228, 227);
			tabbtnchecked:Hide();
		end
	end
	self.data.curTabIndex = nToolType;
	local listWidth = 436;
	if self:GetDisplayBoardSwitch() then
		listWidth = 536;
	end
	getglobal("ToolObjLibBodyList"..self.data.curTabIndex):initData(listWidth, 485, 7, 1,true);
	--没有数据显示文字
	if self:numberOfCellsInTableView() <= 0 then
		self.emptyFont:SetText(GetS(self.define.emptyString[nToolType]))
	else
		self.emptyFont:SetText("")
	end

	--隐藏之前的，显示当前的
	if (oldTabIndex) then
		getglobal("ToolObjLibBodyList"..oldTabIndex):Hide();
	end
	getglobal("ToolObjLibBodyList"..self.data.curTabIndex):Show();
	
	--刷新创建和选择按钮
	if nToolType == 3 then
		self.data.CreateBtn:Show();
		self.data.SelectBtn:Show();
		self.data.SelectBtn:SetPoint("bottomleft", "ToolObjLibBody", "bottomleft", 15, -6);
		self.data.CreateBtn:SetPoint("bottomright", "ToolObjLibBody", "bottomright", -15, -6);
	else
		self.data.CreateBtn:Show();
		self.data.SelectBtn:Hide();
		self.data.CreateBtn:SetPoint("bottom", "ToolObjLibBody", "bottom", 0, -6);
	end
end

--listview 全局回调，获取cell数目
function ToolObjLibView:numberOfCellsInTableView(tableView)
	if (self.data.curLibData == nil) then
		return 0;
	end

	local num = self:GetNumberOfItem(self.data.curTabIndex);
	if self.data.delete == true then
		num = num + 1;
	end
	return num;
end

function ToolObjLibView:GetNumberOfItem(nToolType)
	if (self.data.curLibData == nil) then
		return 0;
	end
	local DataList = self.data.curLibData[nToolType];
	if (DataList == nil) then
		return 0;
	end;
	return #DataList.defList;
end

--listview全局回调，获取cell大小,位置
function ToolObjLibView:tableCellSizeForIndex(tableview, index)
	local listWidth = 415;
	if self:GetDisplayBoardSwitch() then
		listWidth = 515;
	end
	return 11, 5, listWidth, 75;
end

function ToolObjLibView:GetItemCell(tableview, blockIndex)
	--从缓存中取cell复用
	local cell,uiIndex = tableview:dequeueCell(0)
	--没有可复用的，创建cell
	if not cell then 
		local typeName = "Button"
		--ToolObjLibBodyList
		local itemName = tableview:GetName() .. "Item" .. uiIndex 
		local templateName = "ToolObjLib_ItemTemplate"
		if self:GetDisplayBoardSwitch() then
			templateName = "ToolObjLib_ItemTemplate_DisplayboardShow";
		end
		local tableViewName = tableview:GetName()
		cell = UIFrameMgr:CreateFrameByTemplate(typeName,itemName,templateName,tableViewName)
	end
	--根据数据刷新cell
	--返回cell
	cell:Show();
	return cell
end

--listview 滚动全局回调
function ToolObjLibView:tableCellAtIndex(tableview , index)
	local nToolType =  self.data.curTabIndex;
	local item = self:GetItemCell(tableview, index);

	if self.data.curLibData then
		local DataList = self.data.curLibData[nToolType];

		local i = index;
		local checked = self:GetChild("Checked", item);
		local setbtn = self:GetChild("Set", item);
		local okbtn = self:GetChild("Ok", item);
		local name = self:GetChild("Name", item);
		local IconBkg = self:GetChild("IconBkg", item);
		local Icon = self:GetChild("Icon", item);
		if i <= #DataList.defList then
			item:Show();

			local def = DataList.defList[i];
			
			--显示设置按钮还是显示确认按钮
			if self.data.curUseType == 1 then
				setbtn:Show();
				okbtn:Hide();
			else
				setbtn:Hide();
				okbtn:Show();
				
				-- 跳舞方块模式下，区域已经绑定则隐藏确定按钮
				if self.isMiniClub and GetInst("MiniClubInterface"):isAreaBindClub(def.uuid) then 
					okbtn:Hide();
				end
			end

			if i == self.data.checkItemIndex and nToolType == self.data.checkItemOfTab then
				checked:Show();
				self.data.check = checked;
			else
				checked:Hide();
			end

			if def then
				print("i = ", i, ", def.name = ", def.name);
				print("uuid = ", def.uuid);
				name:SetText(def.name);
			end

			if nToolType == 3 then
				--生物显示图标
				Icon:Show();
				IconBkg:Show();
				name:SetAnchorOffset(75, 0);

				if def then
					if def.monsterid == MONSTER_VEHICLE then --物理机械
						SetVehicleModelIcon(Icon, def.monsterid, "", def.userdata, VEHICLE_MODEL);
					else --生物模型Icon
						local monsterdef = MonsterCsv:get(def.monsterid);
						if monsterdef then
							if monsterdef.ModelType == 3 then --Avatar定制模型
								AvatarSetIconByID(monsterdef, Icon)
							elseif monsterdef.ModelType == MONSTER_CUSTOM_MODEL then --微雕模型
								SetModelIcon(Icon, monsterdef.Model, ACTOR_MODEL);
							elseif monsterdef.ModelType == MONSTER_FULLY_CUSTOM_MODEL then --完全自定义模型
								SetModelIcon(Icon, monsterdef.Model, FULLY_ACTOR_MODEL);
							elseif monsterdef.ModelType == MONSTER_IMPORT_MODEL then --导入模型
								SetModelIcon(Icon, monsterdef.Model, IMPORT_ACTOR_MODEL);
							else
								local path = "ui/roleicons/" .. monsterdef.Icon .. ".png";
								Icon:SetTexture(path, true);
							end
						end
					end
				end
			else
				--区域和位置不显示图标
				Icon:Hide();
				IconBkg:Hide();
				name:SetAnchorOffset(13, 0);
			end
		else
			item:Hide();
		end
		if DataList.defList then
			local num = #(DataList.defList);
			local y = num * 80 + 20;
			y = (512 > y and 512) or y;
			getglobal("ToolObjLibBodyList"..nToolType.."Plane"):SetHeight(y);
		end
	else
		self.emptyFont:SetText("")
		item:Hide();
	end
	return item;
end

function ToolObjLibView:GetCheck(nToolType, nItemIndex)
	local item = getglobal("ToolObjLibBodyList"..nToolType):cellAtIndex(nItemIndex-1);
	local checked;
	if (item) then
		checked = self:GetChild("Checked", item);
	end
	return checked;
end

--更新item check状态
function ToolObjLibView:UpdateChecked(nToolType, nItemIndex)
	if (self.data.check) then
		self.data.check:Hide();
	end
	self.data.checkItemOfTab = nToolType; 
	self.data.checkItemIndex = nItemIndex;
	self.data.check = self:GetCheck(nToolType, nItemIndex);
	self.data.check:Show();
end

--删除当前item
--不能使用listview的removeitem方法，因为它仅仅只是删除，没有更新后续的item.
--所以这里的删除就把自身以及后面数据更新，最大所需更新item数据为一页
function ToolObjLibView:DeleteCheckItem()
	self.data.delete = true;
	if (self.data.openMenuItemIndex) then
		self:refreshItem(self.data.openMenuItemIndex);
	end
	self.data.delete = false;
end

--从begin开始更新7个item数据,也就是一页数据
function ToolObjLibView:refreshItem(begin)
	begin = begin or 1;
	local tableview = getglobal("ToolObjLibBodyList"..self.data.curTabIndex);
	local i = begin;
	local endIndex = begin+7;
	while i <= endIndex do
		tableview:updateCellAtIndex(i-1);
		i = i + 1;
	end
end

--更新选中的item check状态
function ToolObjLibView:RefreshCheckItem()
	if (self.data.openMenuItemIndex) then
		getglobal("ToolObjLibBodyList"..self.data.curTabIndex):updateCellAtIndex(self.data.openMenuItemIndex-1);
	end
end

--打开设置菜单
function ToolObjLibView:OpenSetMenu(curTabIndex, nItemIndex)
	local item = getglobal("ToolObjLibBodyList"..curTabIndex):cellAtIndex(nItemIndex-1);
	if item then
		self.data.openMenuItemIndex = nItemIndex;
		local menuFrame = getglobal("ToolObjLibBodyHandle");
		local menu = getglobal("ToolObjLibBodyHandleBody");
		local replaceBtn = getglobal("ToolObjLibBodyHandleBodyReplace");
		local itemUI = item:GetName();

		menu:SetPoint("right", itemUI, "right", -50, 0);
		menuFrame:Show();

		if curTabIndex == 1 or curTabIndex == 4 then
			replaceBtn:Show();
		else
			replaceBtn:Hide();
		end

		local modifyNameNode = getglobal("ToolObjLibBodyHandleBodyModifyNameName");
		if curTabIndex == 4 then
			if modifyNameNode then
				modifyNameNode:SetText(GetS(15009));
			end
		else
			if modifyNameNode then
				modifyNameNode:SetText(GetS(14525));
			end
		end
	end
end

--关闭设置菜单
function ToolObjLibView:CloseSetMenu()
	local menuFrame = getglobal("ToolObjLibBodyHandle");
	if menuFrame:IsShown() then
		menuFrame:Hide();
	end
end

--保存当前的listview里的item数
function ToolObjLibView:UpdateItemNum()
	self.data.oldItemNum[self.data.curTabIndex] = self:GetNumberOfItem(oldTabIndex);
end

function ToolObjLibView:ScrollListEnd(tapType)
	if type(tapType) ~= "number" then
		return;
	end

	if tapType < 1 or tapType > 4 then
		return;
	end

	local listNode = nil;
	if tapType == 1 then
		listNode = getglobal("ToolObjLibBodyList1");
	elseif tapType == 2 then
		listNode = getglobal("ToolObjLibBodyList2");
	elseif tapType == 3 then
		listNode = getglobal("ToolObjLibBodyList3");
	else
		listNode = getglobal("ToolObjLibBodyList4");
	end
	if not listNode then
		return;
	end
	listNode:scrollToBottom();
end